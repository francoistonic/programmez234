// build.gradle 
dependencies {
    // ...
    implementation 'com.google.firebase:firebase-ml-natural-language:19.0.1'
    implementation 'com.google.firebase:firebase-ml-natural-language-smart-reply-model:19.0.1'
}